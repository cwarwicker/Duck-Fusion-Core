<?php

/**
 * Description of Pagination
 * 
 * @copyright 16-Jun-2013
 * @package DuckFusion
 * @version 1
 * @author Conn Warwicker <conn@cmrwarwicker.com>
 */
class Pagination {

    public function __construct() {
        
    }

    public function __destruct() {
        
    }

}

?>
