<?php
namespace DF\Helpers\datastore;



/**
 * Description of Datastore
 *
 * @author cwarwicker
 */
class Datastore {
    
    public static function get($name){
        
        // Try to load disks file
        $file = df_APP_ROOT . df_DS . 'config' . df_DS . 'Disks.php';
        if (!@include_once($file)){
            // need different types of exceptions, e.g. FileNotFound
            throw new \DF\DFException('filesystem', 'File not found', $file);
        }
        
        $disk = (isset($disks) && array_key_exists($name, $disks)) ? $disks[$name] : false;
        if (!$disk){
            throw new \DF\DFException('config', 'Disks configuration not found');
        }
                        
        $manager = new \DF\Helpers\datastore\DatastoreManager();
        $adapterMethod = 'create' . ucfirst($disk['adapter']) . 'Adapter';
        if (method_exists($manager, $adapterMethod)){
            return $manager->$adapterMethod($disk);
        } else {
            throw new \InvalidArgumentException("Datastore adapter {$disk['adapter']} is not supported");
        }
        
    }
    
    
    
}
