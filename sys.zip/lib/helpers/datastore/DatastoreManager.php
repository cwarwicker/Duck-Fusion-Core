<?php

namespace DF\Helpers\datastore;

use League\Flysystem\Filesystem as Flysystem;
use League\Flysystem\AdapterInterface;
use League\Flysystem\Adapter\Local as LocalAdapter;
use League\Flysystem\Adapter\Ftp as FTPAdapter;
use League\Flysystem\Sftp\SftpAdapter as SFTPAdapter;

/**
 * Description of DatastoreManager
 *
 * @author cwarwicker
 */
class DatastoreManager {
    
    public function __construct(){
        
    }
    
    public function createLocalAdapter(array $config){
        $adapter = new LocalAdapter($config['path']);
        return $this->createFileSystem($adapter, $config);
    }
    
    public function createFTPAdapter(array $config){
        $adapter = new FTPAdapter($config);
        return $this->createFileSystem($adapter, $config);
    }
    
    public function createSFTPAdapter(array $config){
        $adapter = new SFTPAdapter($config);
        return $this->createFileSystem($adapter, $config);
    }
    
    public function createAppAdapter(array $config){
        $config['path'] = (isset($config['path'])) ? df_APP_ROOT . df_DS . 'data' . df_DS . $config['path'] : df_APP_ROOT . df_DS . 'data';
        $adapter = new LocalAdapter($config['path']);
        return $this->createFileSystem($adapter, $config);
    }
        
    protected function createFileSystem(AdapterInterface $adapter, array $config = null){
        return new Flysystem($adapter, $config);
    }
    
    
  
}
