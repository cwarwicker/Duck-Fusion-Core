<?php

/**
 * Description of Oracle
 * 
 * @copyright 28-Apr-2013
 * @package DuckFusion
 * @version 1
 * @author Conn Warwicker <conn@cmrwarwicker.com>
 */
class Oracle {

    public function __construct() {
        
    }

    public function __destruct() {
        
    }

}

?>
