<?php

/**
 * Description of Firebird
 * 
 * @copyright 28-Apr-2013
 * @package DuckFusion
 * @version 1
 * @author Conn Warwicker <conn@cmrwarwicker.com>
 */
class Firebird {

    public function __construct() {
        
    }

    public function __destruct() {
        
    }

}

?>
