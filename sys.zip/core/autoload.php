<?php

require_once df_SYS_CORE . 'App.php';
\DF\App::register();

require_once df_SYS_CORE . 'Controller.php';
require_once df_SYS_CORE . 'Model.php';
require_once df_SYS_CORE . 'Quack.php';
require_once df_SYS_CORE . 'Template.php';
require_once df_SYS_CORE . 'Router.php';
require_once df_SYS_CORE . 'Exception.php';
require_once df_SYS_CORE . 'Database.php';

