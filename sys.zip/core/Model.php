<?php

/**
 * Description of Model
 * 
 * @copyright 28-Apr-2013
 * @package DuckFusion
 * @version 1
 * @author Conn Warwicker <conn@cmrwarwicker.com>
 */

namespace DF;

class Model {

    public function __construct() {
        
    }

    public function __destruct() {
        
    }

}

?>
